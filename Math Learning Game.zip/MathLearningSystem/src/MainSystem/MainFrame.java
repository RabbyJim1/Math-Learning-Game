package MainSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.Locale;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import java.awt.Window.Type;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.ImageIcon;

public class MainFrame implements ActionListener {

	private JFrame frmMathGame;
	private JTextField textField;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_2;
    private int question;
    private Timer timer;
	private int second;
	private String sec;
	private int a,b,score,neg;
	private double ans;
	private JLabel lblNewLabel_5;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frmMathGame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainFrame() {
		initialize();
		timer = new Timer(1000,this);
	}
   


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMathGame = new JFrame();
		frmMathGame.setResizable(false);
		frmMathGame.setBackground(Color.BLUE);
		frmMathGame.setTitle("Math Game");
		frmMathGame.setBounds(100, 100, 575, 492);
		frmMathGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMathGame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Select The Number Of Math:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(83, 11, 275, 37);
		frmMathGame.getContentPane().add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
		comboBox.setMaximumRowCount(100);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"}));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
			}
		});
		comboBox.setBounds(358, 11, 85, 31);
		frmMathGame.getContentPane().add(comboBox);
		
		JButton btnNewButton = new JButton("Start Game!");
		btnNewButton.setBackground(new Color(255, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				score = 0;
				neg = 0;
				lblNewLabel_4.setText("");
				String q = (String)comboBox.getSelectedItem();
				question=Integer.parseInt(q);
		
				second=0;
				
				timer.start();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(165, 82, 183, 48);
		frmMathGame.getContentPane().add(btnNewButton);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_1.setBounds(78, 227, 177, 118);
		frmMathGame.getContentPane().add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_2.setBounds(125, 153, 275, 48);
		frmMathGame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField.setBounds(398, 238, 124, 31);
		frmMathGame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Enter Your Ans:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_3.setBounds(234, 238, 139, 31);
		frmMathGame.getContentPane().add(lblNewLabel_3);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(question>=0){
					second=0;
					String s1 = textField.getText();
					double a1= Double.parseDouble(s1);
					if(a1==ans){
						score++;
					}
					else{
						neg++;
					}
					
				}
				
			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSubmit.setBounds(435, 280, 89, 23);
		frmMathGame.getContentPane().add(btnSubmit);
		
		lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setForeground(new Color(255, 0, 0));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_4.setBounds(116, 382, 381, 31);
		frmMathGame.getContentPane().add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon(MainFrame.class.getResource("/MainSystem/img2/math.gif")));
		lblNewLabel_5.setBounds(0, 0, 569, 463);
		frmMathGame.getContentPane().add(lblNewLabel_5);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		second--;
		if(question<=0&&second<=0){
			timer.stop();
			lblNewLabel_1.setText("Game Over!");
		}
		else if(second==-1&&question>=1)
		{
			
			
			second=10;
			question--;
			
			a=(int)(Math.random()*50);
			b=(int)(Math.random()*50);
			int ran=(int)(Math.random()*4);
			if(ran==0){
				
				ans=a+b;
				lblNewLabel_2.setText(String.valueOf(a)+" + "+String.valueOf(b)+" = ?");
			}
			else if(ran==1){
				ans=a-b;
				lblNewLabel_2.setText(String.valueOf(a)+" - "+String.valueOf(b)+" = ?");
			}
			else if(ran==2){
				ans=a*b;
				lblNewLabel_2.setText(String.valueOf(a)+" * "+String.valueOf(b)+" = ?");
				
			}
			else if(ran==3){
				 if(a==0||b==1||a==0||b==1){
			            a = a+2;
			            b = b+2;
			        }
			        if(b>a){
			            int temp = a;
			            a= b;
			            b= temp;
			        }
			        

			        ans = a/b;
			        DecimalFormat df = new DecimalFormat("#.##");
			        String s = df.format(ans);
			        ans = Double.valueOf(s);
			        lblNewLabel_2.setText(String.valueOf(a)+" / "+String.valueOf(b)+" = ?");

			}
			
		}
		
		sec = String.valueOf(second);
		lblNewLabel_1.setText(sec+'s');
		if(second<=0&&question<=0){
			lblNewLabel_1.setText("Game Over!");
			lblNewLabel_4.setText("You give "+score+" correct answer and "+neg+" wrong answer");
			
			
		}
		
	}
}
